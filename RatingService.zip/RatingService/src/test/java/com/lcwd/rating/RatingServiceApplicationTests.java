package com.lcwd.rating;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RatingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
